#!/bin/bash
# ==============================================================================
# AETHER-7 SYSTEMD RESTART WRAPPER
# Installed: 2026-10-01 01:31:45 IST
# Permissions: SUID (root:nexus-svc)
# ==============================================================================

if [ -f /etc/nexus/mira.conf ]; then
    echo "[*] SUID Execution granted to GID $(id -g) ($(id -gn))"
    echo "[*] Triggering root restart of critical services..."
    /usr/bin/systemctl restart aether-core.service
    echo "[+] Done."
else
    echo "[-] Missing configuration."
    exit 1
fi
